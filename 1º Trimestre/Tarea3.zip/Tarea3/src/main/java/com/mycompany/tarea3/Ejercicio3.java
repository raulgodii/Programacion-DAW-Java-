/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea3;
import matematicas.Varias;
import java.util.Scanner;

/**
 * Escribe un programa que pase de binario a decimal.
 * @author raulg
 */

public class Ejercicio3 {
    public static long binarioAdecimal(long n){
        long res = 0;
        long x, p;
        int ndig=Varias.digitos(n);
        
            for(int i=0; i<ndig; i++){
                x = (long)Varias.digitoN(n, i);
                
                p = (long)Varias.potencia(2, ndig-i-1);
                
                System.out.printf("(%d * %d) + ", x, p);
                res = (res + (x*p));            
            }
        System.out.println();
        return res;
    }
    
    public static void comprobarBinario(long n){
        int ndig=Varias.digitos(n);
        long x;
        
            for(int i=0; i<ndig; i++){
                x = (long)Varias.digitoN(n, i);
                if(x!=0 && x!=1){
                    System.out.println("El numero introducido no está en binario");
                    System.exit(0);
                }          
            }
    }
    
    public static void main(String[] args) {
        long n;
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un numero en binario: ");
        n = sc.nextLong();
        comprobarBinario(n);
        
        System.out.printf("El numero \"%d\" en decimal es: %d", n, binarioAdecimal(n));
    }
}
