package com.mycompany.tarea3;
import java.util.Scanner;
import matematicas.Varias;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 * Une y amplía los dos programas anteriores de tal 
 * forma que se permita convertir un número entre 
 * cualquiera de las siguientes bases: decimal, 
 * binario, hexadecimal y octal.
 * 
 * @author raulg
 */

public class Ejercicio5 {
    
    public static boolean base_correcta(int base){
        boolean res = true;
        if(base!=2 && base!=8 && base!= 10 && base!=16){
            res=false;
        }
        return res;
    }
    
    public static void imprimir_menu(){
        System.out.println("- Binario = 2");
        System.out.println("- Octal = 8");
        System.out.println("- Decimal = 10");
        System.out.println("- Hexadecimal = 16");
        System.out.print("--> ");
    }
    
    public static long binarioAdecimal(long n){
        long res = 0;
        long x, p;
        int ndig=Varias.digitos(n);
        
            for(int i=0; i<ndig; i++){
                x = (long)Varias.digitoN(n, i);
                
                p = (long)Varias.potencia(2, ndig-i-1);
                
                System.out.printf("(%d * %d) + ", x, p);
                res = (res + (x*p));            
            }
        System.out.println();
        return res;
    }
    
    public static long octalAdecimal(long n){
        long res = 0;
        long x, p;
        int ndig=Varias.digitos(n);
        
            for(int i=0; i<ndig; i++){
                x = (long)Varias.digitoN(n, i);
                
                p = (long)Varias.potencia(8, ndig-i-1);
                
                System.out.printf("(%d * %d) + ", x, p);
                res = (res + (x*p));            
            }
        System.out.println();
        return res;
    }
    
    public static long hexadecimalAdecimal(String n){
        long res = 0;
        long x, p;
        char c;
        int ndig=n.length();
        n = n.toUpperCase();
        n = n.trim();
        
            for(int i=0; i<ndig; i++){
                c = n.charAt(i);
                switch(c){
                    case 'A': x = 10;
                        break;
                    case 'B': x = 11;
                        break;
                    case 'C': x = 12;
                        break;
                    case 'D': x = 13;
                        break;
                    case 'E': x = 14;
                        break;
                    case 'F': x = 15;
                        break;
                    default: x = Character.getNumericValue(c);
                        break;
                }
                
                p = (long)Varias.potencia(16, ndig-i-1);
                
                System.out.printf("(%d * %d) + ", x, p);
                res = (res + (x*p));            
            }
        System.out.println();
        return res;
    }
    
    public static long decimalAbinario(long n){
        long res=1;
        long r;
        
        while(n>=2){
            r=(n%2);
            res=Varias.pegaPorDetras(res, (int)r);
            n=(n/2);
        }

        res=Varias.pegaPorDetras(res, (int)n);
        res=Varias.voltea(res);
        res=Varias.quitaPorDetras(res, 1);
        return res;
    }
    
    public static long decimalAoctal(long n){
        long res=1;
        long r;
        
        while(n>=8){
            r=(n%8);
            res=Varias.pegaPorDetras(res, (int)r);
            n=(n/8);
        }

        res=Varias.pegaPorDetras(res, (int)n);
        res=Varias.voltea(res);
        res=Varias.quitaPorDetras(res, 1);
        return res;
    }
    
    public static String decimalAhexadecimal(long n){
        String res = "";
        int r;
        String c;
        
        while(n>=16){
            r=(int)(n%16);
            switch(r){
                    case 10: c = "A";
                        break;
                    case 11: c = "B";
                        break;
                    case 12: c = "C";
                        break;
                    case 13: c = "D";
                        break;
                    case 14: c = "E";
                        break;
                    case 15: c = "F";
                        break;
                    default: c = String.valueOf(r);
                        break;
            }
            res = c + res;
            n=(n/16);
        }
        res = String.valueOf(n) + res;

        return res;
    }
    
    public static boolean numero_correcto(long n, int base){
        boolean res = true;
        int dig;
        
        for(int i=0; i<Varias.digitos(n); i++){
            dig = Varias.digitoN(n, i);
            if(dig >= base || dig<0){
                res = false;
            }
        }
        
        return res;
    }
    
    public static boolean comprobar_hex(String hex){
        boolean res = true;
        char c;
        
        for(int i=0; i<hex.length(); i++){
            c = hex.charAt(i);
            if (!Character.isDigit(c)){
                c = Character.toUpperCase(c);
                if(c!='A' && c!='B' && c!='C' && c!='D' && c!='E' && c!='F'){
                    res = false;
                }
            }
        }
        
        return res;
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner (System.in);
        int base_inicial, base_final;
        long n = Long.MIN_VALUE;
        long n_inicial = Long.MIN_VALUE;
        String s_inicial = "";
        String hex = "";
        
        System.out.println("Indica que base es la inicial: ");
        imprimir_menu();
        base_inicial = sc.nextInt();
        while(!base_correcta(base_inicial)){
            System.out.println("Indica una base correcta (2, 8, 10, 16): ");
            System.out.print("--> ");
            base_inicial = sc.nextInt();
        }
        
        System.out.println("Indica que base es la final: ");
        imprimir_menu();
        base_final = sc.nextInt();
        while(!base_correcta(base_final)){
            System.out.println("Indica una base correcta (2, 8, 10, 16): ");
            System.out.print("--> ");
            base_final = sc.nextInt();
        }
        
        if(base_inicial !=16){
            System.out.printf("Introduce el numero en base %d: ", base_inicial);
            n = sc.nextLong();
            
            while(numero_correcto(n, base_inicial)==false){
                System.out.println("Numero incorrecto");
                System.out.printf("Introduce el numero en base %d: ", base_inicial);
                n = sc.nextLong();
            }
            
            n_inicial = n;
        }
        
        if(base_inicial == 16){
            System.out.printf("Introduce el numero en base %d: ", base_inicial);
            hex = sc.next();
            while(comprobar_hex(hex)==false){
                System.out.println("Numero incorrecto");
                System.out.printf("Introduce el numero en base %d: ", base_inicial);
                hex = sc.next();
            }
            s_inicial = hex;
        }
        
        //BINARIO
        if(base_inicial == 2){
            //BINARIO A BINARIO
            if(base_final==2){
                System.out.printf("\n--> RESULTADO \n");
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //BINARIO A OCTAL
            if(base_final==8){
                System.out.printf("\n--> RESULTADO \n");
                n = binarioAdecimal(n);
                n = decimalAoctal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //BINARIO A DECIMAL
            if(base_final==10){
                System.out.printf("\n--> RESULTADO \n");
                n = binarioAdecimal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //BINARIO A HEXADECIMAL
            if(base_final==16){
                System.out.printf("\n--> RESULTADO \n");
                n = binarioAdecimal(n);
                hex = decimalAhexadecimal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %s", n_inicial, base_inicial, base_final, hex);
            }
        }
        
        //OCTAL
        if(base_inicial == 8){
            //OCTAL A BINARIO
            if(base_final==2){
                System.out.printf("\n--> RESULTADO \n");
                n = octalAdecimal(n);
                n = decimalAbinario(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //OCTAL A OCTAL
            if(base_final==8){
                System.out.printf("\n--> RESULTADO \n");
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //OCTAL A DECIMAL
            if(base_final==10){
                System.out.printf("\n--> RESULTADO \n");
                n = octalAdecimal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //OCTAL A HEXADECIMAL
            if(base_final==16){
                System.out.printf("\n--> RESULTADO \n");
                n = octalAdecimal(n);
                hex = decimalAhexadecimal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %s", n_inicial, base_inicial, base_final, hex);
            }
        }
        
        //DECIMAL
        if(base_inicial == 10){
            //DECIMAL A BINARIO
            if(base_final==2){
                System.out.printf("\n--> RESULTADO \n");
                n = decimalAbinario(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //DECIMAL A OCTAL
            if(base_final==8){
                System.out.printf("\n--> RESULTADO \n");
                n = decimalAoctal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //DECIMAL A DECIMAL
            if(base_final==10){
                System.out.printf("\n--> RESULTADO \n");
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %d", n_inicial, base_inicial, base_final, n);
            }
            
            //DECIMAL A HEXADECIMAL
            if(base_final==16){
                System.out.printf("\n--> RESULTADO \n");
                hex = decimalAhexadecimal(n);
                System.out.printf("\n--> Pasar el numero %d en base %d a base %d: %s", n_inicial, base_inicial, base_final, hex);
            }
        }
        
        //HEXADECIMAL
        if(base_inicial == 16){
            //HEXADECIMAL A BINARIO
            if(base_final==2){
                System.out.printf("\n--> RESULTADO \n");
                n = hexadecimalAdecimal(hex);
                n = decimalAbinario(n);
                System.out.printf("\n--> Pasar el numero %s en base %d a base %d: %d", s_inicial, base_inicial, base_final, n);
            }
            
            //HEXADECIMAL A OCTAL
            if(base_final==8){
                System.out.printf("\n--> RESULTADO \n");
                n = hexadecimalAdecimal(hex);
                n = decimalAoctal(n);
                System.out.printf("\n--> Pasar el numero %s en base %d a base %d: %d", s_inicial, base_inicial, base_final, n);
            }
            
            //HEXADECIMAL A DECIMAL
            if(base_final==10){
                System.out.printf("\n--> RESULTADO \n");
                n = hexadecimalAdecimal(hex);
                System.out.printf("\n--> Pasar el numero %s en base %d a base %d: %d", s_inicial, base_inicial, base_final, n);
            }
            
            //HEXADECIMAL A HEXADECIMAL
            if(base_final==16){
                System.out.printf("\n--> RESULTADO \n");
                System.out.printf("\n--> Pasar el numero %s en base %d a base %d: %s", s_inicial, base_inicial, base_final, hex);
            }
        }
    }
}
