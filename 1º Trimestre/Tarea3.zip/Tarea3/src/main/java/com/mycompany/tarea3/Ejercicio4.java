/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea3;

import matematicas.Varias;
import java.util.Scanner;

/**
 * Escribe un programa que pase de decimal a binario
 * @author raulg
 */
public class Ejercicio4 {
    
    public static long DecimalABinario(long n){
        long res=1;
        long r;
        
        
        while(n>=2){
            r=(n%2);
            res=Varias.pegaPorDetras(res, (int)r);
            n=(n/2);
        }

        res=Varias.pegaPorDetras(res, (int)n);
        res=Varias.voltea(res);
        res=Varias.quitaPorDetras(res, 1);
        return res;
    }
    
    public static void main(String[] args) {
        long n;
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un numero en decimal: ");
        n = sc.nextLong();
        
        Varias.pegaPorDelante(n, 564565);
        System.out.printf("El numero \"%d\" en binario es: %d", n, DecimalABinario(n));
    }
}
