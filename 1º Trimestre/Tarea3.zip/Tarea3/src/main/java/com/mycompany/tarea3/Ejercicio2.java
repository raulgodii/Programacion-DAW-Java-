/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea3;

import matematicas.Varias;
/**
 * Muestra los números capicúa que hay entre 1 y 99999.
 * @author raulg
 */
public class Ejercicio2 {
    public static void main(String[] args) {
        
        for(int i = 1; i < 99999; i++){
            if(Varias.esCapicua(i)){
                System.out.printf("%d ", i);
            }
        }
    }
}
