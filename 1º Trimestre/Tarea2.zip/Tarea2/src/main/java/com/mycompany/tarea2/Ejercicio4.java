/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea2;

import java.util.Scanner;

/**
 *
 * @author raulg
 */
public class Ejercicio4 {
    public static void main(String[] args) {
        System.out.println("ESCALERA INCREMENTAL");
        System.out.println("------------------------");
        Scanner leer = new Scanner(System.in);
        int n;
        int j=1;
        
        do{
            System.out.print("Introduce un numero del 1 al 10: ");
            n=leer.nextInt();
        } while(n<1 || n>10);
        
        for(int i=1; i<=n; i++){
            System.out.printf("%d: ", i);
            for(int a=0; a<i; a++){
                System.out.printf("%d ", j);
                j++;
            }
            System.out.println();
        }
    }
}
