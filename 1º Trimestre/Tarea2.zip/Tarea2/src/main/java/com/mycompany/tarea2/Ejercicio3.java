/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea2;

import java.util.Scanner;

/**
 *
 * @author raulg
 */
public class Ejercicio3 {

    public static void main(String[] args) {
    
        final int min = 0;
        final int max = 50;
        final int intentos = 3;

        System.out.println("ENTRENAMIENTO DE NATACION");
        System.out.println("------------------------");
        
        int largos;
        int n=0;
        
        Scanner leer = new Scanner(System.in);
        
            
        for(int i=0; i<intentos; i++){
            System.out.print("Introduce el numero de largos: ");
            largos=leer.nextInt();
            if(largos>=0 && largos<=50){
                System.out.print("{ ");
                do{
                    if(n<largos){
                        System.out.print("Crol, ");
                        n++;
                    }
                    if(n<largos){
                        System.out.print("Espalda, ");
                        n++;
                    }
                    if(n<largos){
                        System.out.print("Braza, ");
                        n++;
                    }
                    if(n<largos){
                        System.out.print("Espalda, ");
                        n++;
                    }
                } while (n<largos);
                System.out.print(" }");
                return;
            }
        }
        
        System.out.println("--> Fin del programa");
    }
}