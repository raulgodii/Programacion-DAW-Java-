/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tarea2;

import java.util.Scanner;

/**
 *
 * @author raulg
 */
public class Ejercicio1 {

    public static void main(String[] args) {
        System.out.println("CALCULO DE LA ESTACION DE TU NACIMIENTO");
        System.out.println("----------------------------------------");
        
        int dia, mes;
        Scanner leer = new Scanner(System.in);
        
        System.out.print("Introduce el mes: ");
        
        mes=leer.nextInt();
        if(mes<1){
            System.out.println("Error, debes introducir un numero entre el 1 y el 12");
            return;
        }
        if(mes>12){
            System.out.println("Error, debes introducir un numero entre el 1 y el 12");
            return;
        }
        
        System.out.print("Introduce el dia: ");
        
        dia=leer.nextInt();
        if(dia<1){
            System.out.println("Error, debes introducir un numero entre el 1 y el 31");
            return;
        }
        if(dia>31){
            System.out.println("Error, debes introducir un numero entre el 1 y el 31");
            return;
        }
        
        if(mes==1 || mes==2){
            System.out.println("---- Naciste en Invierno ----");
            return;
        }
        if(mes==3){
            if(dia<20){
                System.out.println("---- Naciste en Invierno ----");
            } else {
                System.out.println("---- Naciste en Primavera ----");
            }
            return;
        }
        if(mes==4 || mes==5){
            System.out.println("---- Naciste en Primavera ----");
            return;
        }
        if(mes==6){
            if(dia<21){
                System.out.println("---- Naciste en Primavera ----");
            } else {
                System.out.println("---- Naciste en Verano ----");
            }
            return;
        }
        if(mes==7 || mes==8){
            System.out.println("---- Naciste en Verano ----");
            return;
        }
        if(mes==9){
            if(dia<23){
                System.out.println("---- Naciste en Verano ----");
            } else {
                System.out.println("---- Naciste en Otoño ----");
            }
            return;
        }
        if(mes==10 || mes==11){
            System.out.println("---- Naciste en Otoño ----");
        }
        if(mes==12){
            if(dia<21){
                System.out.println("---- Naciste en Otoño ----");
            } else {
                System.out.println("---- Naciste en Invierno ----");
            }
        }
    }
}
