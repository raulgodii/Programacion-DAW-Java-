/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tarea2;

import java.util.Scanner;

/**
 *
 * @author raulg
 */
public class Ejercicio2 {
    
        public static void main(String[] args) {
        System.out.println("CALCULO DEL NUMERO DE DIAS DE UN MES");
        System.out.println("----------------------------------------");
        
        int mes;
        Scanner leer = new Scanner(System.in);
        
        System.out.print("Introduce el mes: ");
        
        mes=leer.nextInt();
        
        switch(mes){
            case 1: //Enero
                System.out.println("--> Tiene 31 dias");
                break;
            case 2: //Febrero
                System.out.println("--> Tiene 28 dias");
                break;
            case 3: //Marzo
                System.out.println("--> Tiene 31 dias");
                break;
            case 4: //Abril
                System.out.println("--> Tiene 30 dias");
                break;
            case 5: //Mayo
                System.out.println("--> Tiene 31 dias");
                break;
            case 6: //Junio
                System.out.println("--> Tiene 30 dias");
                break;
            case 7: //Julio
            case 8: //Agosto
                System.out.println("--> Tiene 31 dias");
                break;
            case 9: //Septiembre
                System.out.println("--> Tiene 30 dias");
                break;
            case 10: //Octubre
                System.out.println("--> Tiene 31 dias");
                break;
            case 11: //Noviembre
                System.out.println("--> Tiene 30 dias");
                break;
            case 12: //Diciembre
                System.out.println("--> Tiene 31 dias");
                break;
                
            default:
                System.out.println("--> Tiene 0 dias");
                break;
        }
        }
        
}
